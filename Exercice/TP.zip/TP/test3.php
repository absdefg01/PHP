<form action="verif_sondage.php" method="post">
 
<input type"text" name="pseudo" />
<input type="radio" name="choix" id="op" value=""  />
 
 
<a href="result_sondage.php" target=popup onClick="window.open('','popup','width=700,height=400,left=200,top=200,scrollbars=1')"><input type="submit" name="go" value="vote" id="vote" style="width:100px"  /></a>
</form>
