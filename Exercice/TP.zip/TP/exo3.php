<?php
$jour=2;

switch($jour){
	case 1:
		echo "Nous sommes lundi";
	break;

	case 2:
		echo "Nous sommes mardi";
	break;

	case 3:
		echo "Nous sommes mercredi";
	break;

	case 4:
		echo "Nous sommes jeudi";
	break;

}
?>
