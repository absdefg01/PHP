<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Page de test</title>
</head>
<body>
<h1>Page de test </h1>
<?php
echo "Hello World ! <br/> Bonjour &agrave; tous !" ;
?>
<br/>
<?php
$age=19;
echo"J'ai $age ans.";
?>
</body>
</html>
