<?php
$age=$_POST['age'];
$nom=$_POST['nom'];

echo"Bonjour $nom, vous avez $age ans.";
	

?>
