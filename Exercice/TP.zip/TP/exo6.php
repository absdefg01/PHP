<HTML>
<head>
<title>Formulaire</title>
</head>


<body>
<form method='post' action='exo6b.php'>
<center>	Votre nom	<input type='text' name = 'nom'></input>
</br></br> 	Votre age	<input type='text' name = 'age'></input>
</br></br> 			<input type='submit' ></input>
</center></form>
</body>

</HTML>


