<?php 
$chaine1="bonjoure";
$chaine2="Bonjour";

if (strcmp ($chaine1, $chaine2) < 0)
{ 
	echo 	"Les deux chaines de caract&egrave;res ont la m&ecirc;me valeur!";
}
else
{
	echo 	"Les deux chaines de caract&egrave;res n'ont pas la m&ecirc;me valeur!";
}


?>
